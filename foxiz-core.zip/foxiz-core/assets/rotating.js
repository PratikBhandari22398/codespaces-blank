document.addEventListener('DOMContentLoaded', () => {
    class RotatingWords {
        constructor(el, duration = 3000) {
            this.el = el;
            this.duration = duration;
            this.words = el.querySelectorAll('.rotating-text .word');
            this.state = { activeIndex: 0, visible: true };
            this.init();
        }

        calcWidth() {
            const container = this.el.querySelector('.rotating-text');
            const currentWidth = container.offsetWidth;
            container.style.width = '';
            const span = this.words[this.state.activeIndex].querySelector('span');
            const newWidth = span.offsetWidth + 2;
            container.style.width = currentWidth + 'px';
            setTimeout(() => container.style.width = newWidth + 'px', 10);
        }

        sequence() {
            if (this.words.length < 2 || !this.state.visible) return;
            this.words[this.state.activeIndex].classList.remove('active');
            this.state.activeIndex = (this.state.activeIndex + 1) % this.words.length;
            this.calcWidth();
            this.words[this.state.activeIndex].classList.add('active');
        }

        init() {
            this.words[this.state.activeIndex].classList.add('active');
            this.calcWidth();
            setInterval(() => this.sequence(), this.duration);
        }
    }

    document.querySelectorAll('.rotating-words').forEach(el => {
        const duration = el.dataset.duration ? parseInt(el.dataset.duration, 10) : 3000;
        new RotatingWords(el, duration);
    });
});