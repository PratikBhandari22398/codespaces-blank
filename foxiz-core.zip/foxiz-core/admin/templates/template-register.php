<?php
/** Don't load directly */
defined( 'ABSPATH' ) || exit;

?>
<div class="rb-dashboard-wrap">
	<div class="rb-dashboard-intro rb-dashboard-section rb-dashboard-fw">
		<div class="rb-intro-content">
			<div class="rb-intro-content-inner">
				<h1 class="rb-dashboard-headline"><?php esc_html_e( 'Offline Demo Mode', 'foxiz-core' ); ?></h1>
				<p class="rb-dashboard-tagline"><?php esc_html_e( 'This sanitized build disables license registration, vendor API calls, remote updates, and demo imports. Use Theme Options to configure the demo site manually.', 'foxiz-core' ); ?></p>
			</div>
			<div class="rb-intro-featured">
				<img src="<?php echo esc_url( FOXIZ_CORE_URL . 'admin/assets/dashboard.jpg' ); ?>" alt="<?php esc_attr_e( 'Home', 'foxiz-core' ); ?>">
			</div>
		</div>
		<div class="rb-dashboard-steps">
			<div class="rb-dashboard-step is-checked">
				<h3><?php esc_html_e( 'License UI Hidden', 'foxiz-core' ); ?></h3>
				<p class="rb-dashboard-desc"><?php esc_html_e( 'No fake activation data is written and no purchase-code validation is attempted in this offline demo build.', 'foxiz-core' ); ?></p>
				<div class="rb-step-icon"><i class="rbi-dash rbi-dash-check"></i></div>
			</div>
			<div class="rb-dashboard-step disabled">
				<h3><?php esc_html_e( 'Remote Imports Disabled', 'foxiz-core' ); ?></h3>
				<p class="rb-dashboard-desc"><?php esc_html_e( 'Prebuilt demo/template imports are disabled to avoid contacting the vendor API or untrusted mirrors.', 'foxiz-core' ); ?></p>
				<div class="rb-step-icon is-checked"><i class="rbi-dash rbi-dash-layer"></i></div>
			</div>
			<a class="rb-dashboard-step" href="<?php echo ! empty( $menu['options']['url'] ) ? esc_url( $menu['options']['url'] ) : '#'; ?>">
				<h3><?php esc_html_e( 'Manual Setup', 'foxiz-core' ); ?></h3>
				<p class="rb-dashboard-desc"><?php esc_html_e( 'Customize the theme locally through Theme Options and your own WordPress content.', 'foxiz-core' ); ?></p>
				<div class="rb-step-icon is-checked"><i class="rbi-dash rbi-dash-arrow-right"></i></div>
			</a>
		</div>
	</div>
	<div class="rb-dashboard-section rb-dashboard-fw">
		<div class="rb-section-header"><h2>
				<i class="rbi-dash rbi-dash-info"></i><?php esc_html_e( 'PHP Information', 'foxiz-core' ); ?></h2></div>
		<div class="rb-info-content">
			<?php
			if ( ! empty( $system_info ) && is_array( $system_info ) ) :
				foreach ( $system_info as $info => $val ) :
					$class_name = 'info-el';
					if ( isset( $val['passed'] ) && ! $val['passed'] ) {
						$class_name .= ' is-warning';
					}
					?>
					<div class="<?php echo esc_attr( $class_name ); ?>">
						<div class="info-content">
							<span class="info-label"><?php echo esc_html( $val['title'] ); ?></span>
							<span class="info-value"><?php echo esc_html( $val['value'] ); ?></span>
						</div>
						<?php if ( isset( $val['passed'] ) && ! $val['passed'] ) : ?>
							<span class="info-warning"><?php echo esc_html( $val['warning'] ); ?></span>
						<?php endif; ?>
					</div>
					<?php
				endforeach;
			endif;
			?>
		</div>
	</div>
</div>
