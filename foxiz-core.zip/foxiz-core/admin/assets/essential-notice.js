var RB_ESSENTIAL_NOTICE = (function (Module, $) {
	'use strict';

	Module.configs = foxizNotice || {};

	Module.init = function () {
		this.prompt = $('#rb-essential-prompt');
		if (!this.prompt.length) return;

		this.statusEl = $('#rb-notice-status');
		this.dismiss();
		this.bulkInstall();
	};

	/** dismiss */
	Module.dismiss = function () {
		var self = this;

		this.prompt.on('click', '.notice-dismiss', function () {
			$.post(self.configs.ajaxUrl, {
				action: 'rb_dismiss_essential',
				_nonce: self.configs.nonce,
			});
		});
	};

	/** get plugin title */
	Module.getPluginTitle = function (pluginName) {
		var titles = this.configs.pluginTitles || {};
		return titles[pluginName] || pluginName;
	};

	/** update inline status */
	Module.setStatus = function (text, isError) {
		var statusClass = isError ? 'is-error' : 'is-success';
		this.statusEl.removeClass('is-error is-success').addClass(statusClass).text(text);
	};

	/** bulk install */
	Module.bulkInstall = function () {
		var self = this;

		$('#rb-notice-install-btn').on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			var btn = $(this);
			var plugins = self.configs.plugins || [];
			var total = plugins.length;

			if (total < 1 || btn.prop('disabled')) return;

			btn.prop('disabled', true);
			btn.find('.rb-loading').removeClass('is-hidden').show();

			var current = 0;

			function processNext() {
				if (current >= total) {
					btn.find('.button-label').text(self.configs.done || 'All Done!');
					btn.find('.rb-loading').hide();
					btn.addClass('is-complete');
					self.setStatus('✓ ' + total + '/' + total + ' ' + (self.configs.completed || 'completed'), false);
					setTimeout(function () {
						window.location.href = self.configs.dashboardUrl;
					}, 2000);
					return;
				}

				var pluginName = plugins[current];
				var pluginTitle = self.getPluginTitle(pluginName);
				var progress = (current + 1) + '/' + total;

				// Update status
				self.setStatus(progress + ' ' + (self.configs.installing || 'Installing') + ' ' + pluginTitle + '...', false);

				$.ajax({
					type: 'POST',
					dataType: 'json',
					url: self.configs.ajaxUrl,
					data: {
						action: 'rb_recommended_plugin',
						plugin: pluginName,
						_nonce: self.configs.nonce,
					},
					success: function (response) {
						if (response && response.data && response.data.status === 'is-inactive') {
							// Plugin installed but needs activation
							self.setStatus(progress + ' ' + (self.configs.activating || 'Activating') + ' ' + pluginTitle + '...', false);

							$.ajax({
								type: 'POST',
								dataType: 'json',
								url: self.configs.ajaxUrl,
								data: {
									action: 'rb_recommended_plugin',
									plugin: pluginName,
									_nonce: self.configs.nonce,
								},
								success: function () {
									current++;
									processNext();
								},
								error: function () {
									current++;
									processNext();
								},
							});
							return;
						}

						current++;
						processNext();
					},
					error: function () {
						self.setStatus(progress + ' ' + pluginTitle + ' - ' + (self.configs.failed || 'Failed'), true);
						current++;
						setTimeout(processNext, 500);
					},
				});
			}

			processNext();
		});
	};

	return Module;
})(RB_ESSENTIAL_NOTICE || {}, jQuery);

jQuery(document).ready(function () {
	if (typeof foxizNotice !== 'undefined') {
		RB_ESSENTIAL_NOTICE.init();
	}
});
