var RB_ADMIN_CORE = (function (Module, $) {
	'use strict';

	Module.isAjaxProgressing = false;
	Module.globalConfigs = foxizAdminCore || {};

	Module.init = function () {
		this.registerForm = $('#rb-register-theme-form');
		this.deregisterForm = $('#rb-deregister-theme-form');

		this.registerPurchase();
		this.deregisterPurchase();
		this.recommendedPlugin();
		/** search */
		this.dashboardSearch();

		/** importer */
		this.fetchTokenData();
		this.cleanupImportData();
		this.initImport();

		/** translation */
		this.toggleTranslationPanel();
		this.autoTranslation();
		this.fetchTranslation();
		this.updateTranslation();
		this.exportTranslation();
		this.importTranslation();
		this.clearTranslation();

		/** fonts */
		this.updateFontProject();
		this.deleteFontProject();

		/** GTM tag */
		this.deleteGTMTag();
		this.addGTMTag();
	};

	/** toast notification */
	Module.showToast = function (message, isError) {
		var container = document.querySelector('.rb-toast-container');
		if (!container) {
			container = document.createElement('div');
			container.className = 'rb-toast-container';
			document.body.appendChild(container);
		}

		var toast = document.createElement('div');
		toast.className = 'rb-toast' + (isError ? ' is-error' : '');
		var icon = isError ? 'rbi-dash-close' : 'rbi-dash-check';
		var textNode = document.createTextNode(message);
		var iconEl = document.createElement('i');
		iconEl.className = 'rbi-dash ' + icon;
		toast.appendChild(iconEl);
		toast.appendChild(document.createTextNode(' '));
		toast.appendChild(textNode);
		container.appendChild(toast);

		// Force reflow then animate in
		toast.offsetWidth;
		toast.classList.add('is-visible');

		setTimeout(function () {
			toast.classList.remove('is-visible');
			setTimeout(function () {
				if (toast.parentNode) {
					toast.parentNode.removeChild(toast);
				}
			}, 300);
		}, 3500);
	};

	/** register */
	Module.registerPurchase = function () {
		const self = this;
		if (self.registerForm.length) {
			const submitBtn = self.registerForm.find('#rb-register-theme-btn');
			const loading = self.registerForm.find('.rb-loading');
			const messenger = self.registerForm.find('.rb-response-info');
			submitBtn.on('click', function (e) {
				e.preventDefault();
				e.stopPropagation();

				const data = self.getFormData($(self.registerForm));
				if (!data.nonce || !data.purchaseCode || !data.emailInfo || self.isAjaxProgressing) {
					return;
				}

				self.isAjaxProgressing = true;
				self.setButtonWidth(submitBtn);

				$.ajax({
					type: 'POST',
					async: true,
					dataType: 'json',
					url: self.globalConfigs.ajaxUrl,
					data: {
						action: 'rb_register_theme',
						purchase_code: data.purchaseCode,
						email: data.emailInfo,
						_nonce: data.nonce,
					},
					beforeSend: function (xhr) {
						self.isAjaxProgressing = true;
						loading.fadeIn(300).removeClass('is-hidden');
						submitBtn.attr('disabled', 'disabled');
					},
					success: function (response) {
						if ('undefined' != typeof response.data) {
							loading.fadeOut(300).addClass('is-hidden');
							messenger
								.html('<p class="info-success">' + response.data + '</p>')
								.removeClass('is-hidden');
						}
						setTimeout(function () {
							location.reload();
						}, 1500);
					},
					error: function (xhr, status, error) {
						if (xhr.responseJSON && xhr.responseJSON.data) {
							loading.fadeOut(300).addClass('is-hidden');
							messenger.html(xhr.responseJSON.data).removeClass('is-hidden');
						}
					},
				});
				return false;
			});
		}
	};

	Module.setButtonWidth = function (target) {
		target.css('min-width', target.outerWidth() + 'px');
	};

	/** deregisterPurchase */
	Module.deregisterPurchase = function () {
		const self = this;
		if (self.deregisterForm.length) {
			const submitBtn = self.deregisterForm.find('#rb-deregister-theme-btn');
			const loading = self.deregisterForm.find('.rb-loading');
			const messenger = self.deregisterForm.find('.rb-response-info');

			submitBtn.on('click', function (e) {
				e.preventDefault();
				e.stopPropagation();
				const userConfirmed = window.confirm(self.globalConfigs.confirmDeactivate);
				if (userConfirmed === false) {
					return;
				}

				if (self.isAjaxProgressing) return;
				self.isAjaxProgressing = true;

				self.setButtonWidth(submitBtn);
				const data = self.getFormData($(self.deregisterForm));

				if (!data.nonce) {
					return;
				}

				$.ajax({
					type: 'POST',
					async: true,
					dataType: 'json',
					url: self.globalConfigs.ajaxUrl,
					data: {
						action: 'rb_deregister_theme',
						_nonce: data.nonce,
					},
					beforeSend: function (xhr) {
						self.isAjaxProgressing = true;
						loading.fadeIn(300).removeClass('is-hidden');
						submitBtn.attr('disabled', 'disabled');
					},
					success: function (response) {
						response = JSON.parse(JSON.stringify(response));
						if (response.data) {
							submitBtn.val(self.globalConfigs.reload);
							messenger
								.html('<p class="info-success">' + response.data + '</p>')
								.removeClass('is-hidden');
						}
						setTimeout(function () {
							location.reload();
						}, 4000);
					},
					error: function (xhr, status, error) {
						if (xhr.responseJSON && xhr.responseJSON.data) {
							loading.fadeOut(300).addClass('is-hidden');
							messenger.html(xhr.responseJSON.data).removeClass('is-hidden');
						}
					},
				});
				return false;
			});
		}
	};

	/** recommendedPlugin */
	Module.recommendedPlugin = function () {
		const self = this;
		const submitBtn = $('.ruby-install-plugin');

		submitBtn.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			const target = $(this);
			const wrapper = target.parents('.rb-plugin');
			const name = target.data('plugin');
			const loading = target.find('.rb-loading');
			const btnLabel = target.find('.button-label');
			const error = wrapper.find('.rb-plugin-error');
			const status = wrapper.find('.rb-plugin-status');

			if (self.isAjaxProgressing) return;

			self.isAjaxProgressing = true;
			self.setButtonWidth(target);

			var prevStatus = wrapper.attr('data-status');

			$.ajax({
				type: 'POST',
				async: true,
				dataType: 'json',
				url: self.globalConfigs.ajaxUrl,
				data: {
					action: 'rb_recommended_plugin',
					plugin: name,
					_nonce: self.globalConfigs._rbNonce,
				},
				beforeSend: function (xhr) {
					self.isAjaxProgressing = true;
					loading.css('display', 'flex').removeClass('is-hidden');
					submitBtn.attr('disabled', 'disabled');
				},

				success: function (response) {
					self.isAjaxProgressing = false;
					response = JSON.parse(JSON.stringify(response));
					loading.fadeOut(300, function () {
						loading.addClass('is-hidden');
						if (response && response.data) {
							btnLabel.html(response.data.btnLabel);
							status.html(response.data.statusLabel);
							wrapper.attr('data-status', response.data.status);
							submitBtn.removeAttr('disabled');

							var pluginTitle = wrapper.find('.rb-plugin-title').text().trim();
							var newStatus = response.data.status;
							var isDeactivate = prevStatus === 'is-active' && newStatus === 'is-inactive';
							var toastLabel = newStatus === 'is-active' ? 'Activated'
								: (prevStatus === 'is-not_found' && newStatus === 'is-inactive') ? 'Installed'
								: isDeactivate ? 'Deactivated'
								: response.data.statusLabel;
							self.showToast(pluginTitle + ': ' +toastLabel, isDeactivate);
						}
					});
				},
				error: function (response) {
					response = JSON.parse(JSON.stringify(response.responseJSON));
					self.isAjaxProgressing = false;

					loading.fadeOut(300, function () {
						loading.addClass('is-hidden');
						if (response && response.data) {
							error.html(response.data);
							self.showToast(response.data, true);
						}
					});
				},
			});
		});
	};

	/** bulk install essential plugins */
	Module.bulkInstallPlugins = function () {
		const self = this;
		const bulkBtn = $('#rb-bulk-install-btn');

		bulkBtn.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			if (self.isAjaxProgressing) return;

			const cards = [];
			$('.rb-essential-plugins .rb-plugin').each(function () {
				const status = $(this).attr('data-status');
				if (status !== 'is-active') {
					cards.push($(this));
				}
			});

			if (cards.length === 0) return;

			self.isAjaxProgressing = true;
			bulkBtn.attr('disabled', 'disabled');
			bulkBtn.find('.rb-loading').css('display', 'inline-flex').removeClass('is-hidden');

			let current = 0;
			const total = cards.length;

			function updateLabel(text) {
				bulkBtn.find('.button-label').text(text);
			}

			function processNext() {
				if (current >= total) {
					updateLabel(self.globalConfigs.bulkDone || 'All Installed');
					bulkBtn.find('.rb-loading').fadeOut(300).addClass('is-hidden');
					self.isAjaxProgressing = false;
					self.showToast(self.globalConfigs.bulkDone || 'All plugins installed!', false);
					$('#rb-essential-prompt').fadeOut(400);
					setTimeout(function () {
						window.location.reload();
					}, 1500);
					return;
				}

				const card = cards[current];
				const pluginName = card.find('.ruby-install-plugin').data('plugin');
				updateLabel((current + 1) + '/' + total + '...');

				$.ajax({
					type: 'POST',
					dataType: 'json',
					url: self.globalConfigs.ajaxUrl,
					data: {
						action: 'rb_recommended_plugin',
						plugin: pluginName,
						_nonce: self.globalConfigs._rbNonce,
					},
					success: function (response) {
						if (response && response.data) {
							const status = card.find('.rb-plugin-status');
							const btn = card.find('.ruby-install-plugin');
							const btnLabel = btn.find('.button-label');
							status.html(response.data.statusLabel);
							btnLabel.html(response.data.btnLabel);
							card.attr('data-status', response.data.status);

							if (response.data.status === 'is-inactive') {
								$.ajax({
									type: 'POST',
									dataType: 'json',
									url: self.globalConfigs.ajaxUrl,
									data: {
										action: 'rb_recommended_plugin',
										plugin: pluginName,
										_nonce: self.globalConfigs._rbNonce,
									},
									success: function (res2) {
										if (res2 && res2.data) {
											status.html(res2.data.statusLabel);
											btnLabel.html(res2.data.btnLabel);
											card.attr('data-status', res2.data.status);

											var pTitle = card.find('.rb-plugin-title').text().trim();
											self.showToast(pTitle + ': ' +res2.data.statusLabel, false);
										}
										current++;
										processNext();
									},
									error: function () {
										var pTitle = card.find('.rb-plugin-title').text().trim();
										self.showToast(pTitle + ': Activation failed', true);
										current++;
										processNext();
									},
								});
								return;
							}
						}
						current++;
						processNext();
					},
					error: function () {
						var pTitle = card.find('.rb-plugin-title').text().trim();
						self.showToast(pTitle + ': Install failed', true);
						current++;
						processNext();
					},
				});
			}

			processNext();
		});
	};

	/** dashboard search */
	Module.dashboardSearch = function () {
		const pluginWrap = $('.rb-search-area');
		if (pluginWrap.length) {
			pluginWrap.searcher({
				itemSelector: '.rb-search-item',
				textSelector: 'h3, p, label',
				inputSelector: '#rb-search-form',
				toggle: function (item, containsText) {
					containsText ? $(item).fadeIn(200) : $(item).fadeOut(0);
				},
			});
		}
	};

	/** get form data */
	Module.getFormData = function (form) {
		const data = {};

		const purchaseCodeInput = form.find('[name="purchase_code"]');
		const emailInfoInput = form.find('[name="email"]');

		data.nonce = this.globalConfigs._rbNonce;
		data.purchaseCode = purchaseCodeInput.length ? purchaseCodeInput.val() : '';
		data.emailInfo = emailInfoInput.length ? emailInfoInput.val() : '';

		/** validate */
		if ('' !== data.purchaseCode) {
			purchaseCodeInput.removeClass('rb-validate-error');
			purchaseCodeInput.parent().find('.rb-error-info').addClass('is-hidden');
		} else {
			purchaseCodeInput.addClass('rb-validate-error');
			purchaseCodeInput.parent().find('.rb-error-info').removeClass('is-hidden');
		}

		if ('' !== data.emailInfo) {
			emailInfoInput.removeClass('rb-validate-error');
			emailInfoInput.parent().find('.rb-error-info').addClass('is-hidden');
		} else {
			emailInfoInput.addClass('rb-validate-error');
			emailInfoInput.parent().find('.rb-error-info').removeClass('is-hidden');
		}

		return data;
	};

	/** Quick Translation */
	Module.fetchTranslation = function () {
		const self = this;
		const fetchBtn = $('#rb-fetch-translation');

		fetchBtn.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			const target = $(this);
			if (self.isAjaxProgressing) {
				return;
			}
			self.setButtonWidth(target);

			$.ajax({
				type: 'POST',
				async: true,
				dataType: 'json',
				url: self.globalConfigs.ajaxUrl,
				data: {
					action: 'rb_fetch_translation',
					_nonce: self.globalConfigs._rbNonce,
				},
				beforeSend: function () {
					self.isAjaxProgressing = true;
					target.html(
						`<span class="rb-loading"><i class="rbi-dash rbi-dash-load"></i></span><span>${self.globalConfigs.updating}</span>`
					);
					fetchBtn.attr('disabled', 'disabled');
				},
				success: function () {
					target.html(
						`<span class="rb-loading"><i class="rbi-dash rbi-dash-load"></i></span><span>${self.globalConfigs.reload}</span>`
					);
					setTimeout(function () {
						location.reload();
					}, 500);
				},
				error: function () {
					target.html(self.globalConfigs.error);
				},
			});
		});
	};

	/** update translation */
	Module.updateTranslation = function () {
		const self = this;
		const updateBtn = $('#rb-update-translation');

		updateBtn.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			if (self.isAjaxProgressing) {
				return false;
			}
			self.setButtonWidth(updateBtn);

			const form = $(this).parents('#rb-translation-form');
			const nonce = self.globalConfigs._rbNonce;
			const loading = form.find('.rb-loading');
			const info = form.find('.rb-info');
			let errorText = self.globalConfigs.error;

			let data = 'action=rb_update_translation';
			data += '&_nonce=' + nonce + '';
			data += '&' + form.find('input[type="text"]').serialize();

			$.ajax({
				type: 'POST',
				async: true,
				dataType: 'json',
				url: self.globalConfigs.ajaxUrl,
				data: data,
				beforeSend: function () {
					self.isAjaxProgressing = true;
					loading.removeClass('is-hidden');
					updateBtn.attr('disabled', 'disabled');
				},
				success: function (response) {
					loading.addClass('is-hidden');
					updateBtn.removeAttr('disabled');
					self.isAjaxProgressing = false;
					info.text('Settings Saved!').slideDown(300);
					setTimeout(function () {
						info.slideUp(300);
					}, 2000);
				},
				error: function (xhr, status, error) {
					loading.addClass('is-hidden');
					if (xhr.responseJSON && xhr.responseJSON.data) {
						errorText = xhr.responseJSON.data;
					}
					info.addClass('is-error').text(errorText).slideDown(300);
				},
			});
		});
	};

	/** toggle translation panel */
	Module.toggleTranslationPanel = function () {
		const container = $('.rb-translation-data');
		const triggerBtn = $('#rb-translation-data-trigger');

		// Bind click event to the trigger button
		triggerBtn.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			// Toggle 'is-open' class on the parent container
			container.toggleClass('is-open');
		});

		// Click outside closes the dropdown
		$(document).on('click', function (e) {
			if (!$(e.target).closest('.rb-translation-data').length) {
				container.removeClass('is-open');
			}
		});
	};

	/** export translation */
	Module.exportTranslation = function () {
		const self = this;
		const exportBtn = $('#rb-export-translation');

		// Bind click event to the export button
		exportBtn.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			const target = $(this);

			// Prevent multiple AJAX requests while one is still in progress
			if (self.isAjaxProgressing) {
				return;
			}

			// Preserve button width so it doesn't shrink when text changes
			self.setButtonWidth(target);

			$.ajax({
				type: 'POST',
				async: true,
				dataType: 'json',
				url: self.globalConfigs.ajaxUrl, // WordPress admin-ajax.php URL
				data: {
					action: 'rb_export_translation', // PHP action hook
					_nonce: self.globalConfigs._rbNonce, // Security nonce
				},
				beforeSend: function () {
					self.isAjaxProgressing = true;

					// Show loading animation and disable the button
					target.html(
						`<span class="rb-loading"><i class="rbi-dash rbi-dash-load"></i></span>
                     <span>${self.globalConfigs.exporting || 'Exporting...'}</span>`
					);
					exportBtn.attr('disabled', 'disabled');
				},
				success: function (response) {
					if (response.success) {
						// Convert the PHP data object to a pretty-printed JSON string
						const jsonStr = JSON.stringify(response.data, null, 4);

						// Create a Blob object containing the JSON
						const blob = new Blob([jsonStr], { type: 'application/json' });

						// Create a temporary download URL for the Blob
						const url = URL.createObjectURL(blob);

						// Create an invisible <a> element to trigger the download
						const a = document.createElement('a');
						a.href = url;
						a.download = 'translation-export-' + new Date().toISOString().slice(0, 10) + '.json';
						a.click(); // Programmatically click to start download

						// Release the object URL to free memory
						URL.revokeObjectURL(url);

						// Update button text to indicate success
						target.html(`<span>${self.globalConfigs.downloaded || 'Downloaded!'}</span>`);
					} else {
						// Show error if the AJAX response is not successful
						target.html(self.globalConfigs.error || 'Error!');
					}
				},
				error: function () {
					// Show error if the AJAX request itself fails
					target.html(self.globalConfigs.error || 'Error!');
				},
				complete: function () {
					// Re-enable the button and reset progress flag
					self.isAjaxProgressing = false;
					exportBtn.removeAttr('disabled');
				},
			});
		});
	};

	/** import translation */
	Module.importTranslation = function () {
		const self = this;
		const importBtn = $('#rb-import-translation');
		const fileInput = $('#rb-import-translation-file');

		importBtn.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			if (self.isAjaxProgressing) return;

			// Check if a file is selected
			if (!fileInput[0].files.length) {
				alert(self.globalConfigs.noFileSelected || 'Please select a file to import.');
				return;
			}

			// Confirm with the user before overriding current translations
			const confirmed = confirm(self.globalConfigs.confirmImportTrans || 'Are you sure?');
			if (!confirmed) {
				return; // User cancelled
			}

			const formData = new FormData();
			formData.append('action', 'rb_auto_translation');
			formData.append('_nonce', self.globalConfigs._rbNonce);
			formData.append('translation_file', file);

			self.setButtonWidth(importBtn);

			$.ajax({
				type: 'POST',
				url: self.globalConfigs.ajaxUrl,
				data: formData,
				processData: false,
				contentType: false,
				beforeSend: function () {
					self.isAjaxProgressing = true;
					importBtn.html(
						`<span class="rb-loading"><i class="rbi-dash rbi-dash-load"></i></span>
                     <span>${self.globalConfigs.importing || 'Importing...'}</span>`
					);
					importBtn.attr('disabled', 'disabled');
				},
				success: function (response) {
					if (response.success) {
						importBtn.html(`<span>${self.globalConfigs.imported || 'Imported!'}</span>`);
						// Reload the page after a short delay to show the message
						setTimeout(function () {
							location.reload();
						}, 800); // 0.8 second delay
					} else {
						importBtn.html(self.globalConfigs.error || 'Error!');
						console.error(response.data?.message || 'Import failed');
					}
				},
				error: function () {
					importBtn.html(self.globalConfigs.error || 'Error!');
				},
				complete: function () {
					self.isAjaxProgressing = false;
					importBtn.removeAttr('disabled');
				},
			});
		});
	};

	/**
	 * Auto Translation Module
	 * Sends an AJAX request to fetch translations from the server.
	 * Optimized for readability, error handling, and UI updates.
	 */
	Module.autoTranslation = function () {
		const self = this;
		const autoTranslationBtn = $('#rb-auto-translation');

		autoTranslationBtn.on('click', function (event) {
			event.preventDefault();
			event.stopPropagation();

			if (self.isAjaxProgressing) return;

			const userConfirmed = confirm(self.globalConfigs.confirmAutoTrans || 'Are you sure?');
			if (!userConfirmed) return;

			self.setButtonWidth(autoTranslationBtn);

			$.ajax({
				type: 'POST',
				url: self.globalConfigs.ajaxUrl,
				dataType: 'json',
				data: {
					action: 'rb_auto_translation',
					_nonce: self.globalConfigs._rbNonce,
				},
				beforeSend: function () {
					self.isAjaxProgressing = true;
					autoTranslationBtn
						.html(
							`<span class="rb-loading"><i class="rbi-dash rbi-dash-load"></i></span><span>${self.globalConfigs.translating}</span>`
						)
						.attr('disabled', 'disabled');
				},
				success: function () {
					autoTranslationBtn.html(
						`<span class="rb-loading"><i class="rbi-dash rbi-dash-load"></i></span><span>${self.globalConfigs.reload}</span>`
					);
					setTimeout(() => location.reload(), 800);
				},
				error: function (xhr) {
					let message;
					try {
						const json = JSON.parse(xhr.responseText);
						message = json?.data?.message;
						console.log(message);
					} catch (e) {}
					alert(message || self.globalConfigs.error || 'Request failed.');
					autoTranslationBtn.html(self.globalConfigs.error || 'Error!');
				},
				complete: function () {
					self.isAjaxProgressing = false;
					autoTranslationBtn.removeAttr('disabled');
				},
			});
		});
	};

	Module.clearTranslation = function () {
		const self = this;
		const clearBtn = $('#rb-clear-translation');

		clearBtn.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			if (self.isAjaxProgressing) {
				return;
			}

			const target = $(this);
			self.setButtonWidth(target);

			if (!confirm(self.globalConfigs.confirmClearTrans)) {
				return;
			}

			$.ajax({
				type: 'POST',
				async: true,
				dataType: 'json',
				url: self.globalConfigs.ajaxUrl,
				data: {
					action: 'rb_clear_translation',
					_nonce: self.globalConfigs._rbNonce,
				},
				beforeSend: function () {
					self.isAjaxProgressing = true;
					target.html(
						`<span class="rb-loading"><i class="rbi-dash rbi-dash-load"></i></span><span>${self.globalConfigs.clearing}</span>`
					);
					clearBtn.attr('disabled', 'disabled');
				},
				success: function (response) {
					if (response.success) {
						target.html(self.globalConfigs.cleared);
						setTimeout(function () {
							location.reload();
						}, 500);
					} else {
						target.html(self.globalConfigs.error);
					}
				},
				error: function () {
					target.html(self.globalConfigs.error);
				},
			});
		});
	};

	/** Retrieve a new token, update support duration, and refresh demo data */
	Module.fetchTokenData = function () {
		const self = this;
		$(document).on('click', '.refresh-exp-btn', function (e) {
			e.preventDefault();
			e.stopPropagation();

			const target = $(this);

			if (!target.hasClass('no-confirm')) {
				const confirm = window.confirm(self.globalConfigs.confirmUpdateExp);
				if (confirm === false) {
					return;
				}
			}

			if (self.isAjaxProgressing) return;
			self.setButtonWidth(target);
			self.isAjaxProgressing = true;
			target.html(
				`<span class="rb-loading"><i class="rbi-dash rbi-dash-load"></i></span><span>${self.globalConfigs.updating}</span>`
			);

			jQuery.post(
				self.globalConfigs.ajaxUrl,
				{
					action: 'rb_renew_token',
					_nonce: self.globalConfigs._rbNonce,
				},
				function (response) {
					location.reload();
				}
			);
			return false;
		});
	};

	/** cleaup importer */
	Module.cleanupImportData = function () {
		const self = this;
		const template = wp.template('rb-cleanup');

		$('#rb-cleanup-import').on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			if (self.isAjaxProgressing) return;

			$('body').addClass('rb-importer-activated');
			const renderedHTML = template();
			$('#rb-importer').html(renderedHTML);

			$(document)
				.off('click', '.rb-cleanup-import-data')
				.on('click', '.rb-cleanup-import-data', function (e) {
					e.preventDefault();
					e.stopPropagation();

					const userConfirmed = window.confirm(self.globalConfigs.confirmDeleteImporter);
					if (userConfirmed === false) {
						return;
					}
					const currentStep = $('#rb-importer .activated-step');
					const completeStep = $('#rb-importer .rb-step-complete');
					const errorStep = $('#rb-importer .rb-step-error');
					const loading = $('#rb-importer .rb-cleanup-info');
					const wrapper = $('#rb-importer .rb-cleanup-buttons');
					const closeBtn = $('#rb-importer .rb-close-import');

					self.isAjaxProgressing = true;
					wrapper.hide();
					loading.removeClass('is-hidden');
					closeBtn.addClass('disabled');

					$.ajax({
						type: 'POST',
						url: self.globalConfigs.ajaxUrl,
						dataType: 'json',
						data: {
							action: 'rb_cleanup_content',
							cleanup: $(this).data('cleanup'),
							_nonce: self.globalConfigs._rbNonce,
						},
						success: function () {
							currentStep.removeClass('activated-step');
							completeStep.addClass('activated-step');
						},
						error: function () {
							currentStep.removeClass('activated-step');
							errorStep.addClass('activated-step');
						},
						complete: function () {
							self.isAjaxProgressing = false;
							closeBtn.removeClass('disabled');
						},
					});
				});
		});
	};

	/** import */
	Module.initImport = function () {
		const self = this;
		$(document).on('click', '.rb-do-import', self.showImportPanel.bind(self));
		$(document).on('click', '.rb-close-import', self.closeImport.bind(self));
		$(document).on('click', '#rb-import-next', self.importNextStep.bind(self));
		$(document).on('click', '#rb-import-action', self.importAction.bind(self));
		$(document).on('click', '#rb-import-back', self.importPrevStep.bind(self));
	};

	/** do importer */
	Module.closeImport = function (e) {
		const self = this;
		if (self.isAjaxProgressing) {
			return;
		}
		$('body').removeClass('rb-importer-activated');
	};

	Module.showImportPanel = function (e) {
		e.preventDefault();
		e.stopPropagation();

		const self = this;
		const target = $(e.currentTarget);
		const id = target.data('id');

		if (self.isAjaxProgressing || !id || !self.globalConfigs.importData || !self.globalConfigs.importData[id]) {
			return;
		}

		$('body').addClass('rb-importer-activated');

		const demo = self.globalConfigs.importData[id];
		const template = wp.template('rb-import');
		const renderedHTML = template(demo);
		$('#rb-importer').html(renderedHTML);

		const importAllCheckbox = $('#import_all');
		const otherCheckboxes = $('.rb-importer-checkbox:not(#import_all)');
		const nextButton = $('#rb-import-next');

		function toggleNextBtn() {
			const anyChecked = importAllCheckbox.is(':checked') || otherCheckboxes.is(':checked');
			nextButton.prop('disabled', !anyChecked);
		}

		importAllCheckbox.on('change', function () {
			const isChecked = $(this).is(':checked');
			otherCheckboxes.prop('checked', isChecked);
			toggleNextBtn();
		});

		otherCheckboxes.on('change', function () {
			if (!$(this).is(':checked')) {
				importAllCheckbox.prop('checked', false);
			} else {
				const allChecked = otherCheckboxes.length === otherCheckboxes.filter(':checked').length;
				if (allChecked) {
					importAllCheckbox.prop('checked', true);
				}
			}
			toggleNextBtn();
		});
	};

	Module.importPrevStep = function (e) {
		e.preventDefault();
		e.stopPropagation();

		var currentStep = $('#rb-importer .rb-step-plugin');
		var prevStep = $('#rb-importer .rb-step-select');

		currentStep.removeClass('activated-step');
		prevStep.addClass('activated-step');
	};

	/** action */
	Module.importNextStep = function (e) {
		e.preventDefault();
		e.stopPropagation();

		const target = $(e.currentTarget);
		if (target.is(':disabled')) {
			return;
		}

		const currentStep = $('#rb-importer .rb-step-select');
		const nextStep = $('#rb-importer .rb-step-plugin');

		currentStep.removeClass('activated-step');
		nextStep.addClass('activated-step');
	};

	/** import action */
	Module.importAction = function (e) {
		e.preventDefault();
		e.stopPropagation();

		const self = this;
		const plugins = $('#rb-importer .rb-install-plugin');
		const currentStep = $('#rb-importer .activated-step');
		const nextStep = $('#rb-importer .rb-step-importing');
		const closeBtn = $('#rb-importer .rb-close-import');

		currentStep.removeClass('activated-step');
		nextStep.addClass('activated-step');
		closeBtn.addClass('disabled');

		const settings = {
			directory: $('[data-directory]').data('directory'),
			import_all: $('[data-action="import_all"]').is(':checked'),
			import_content: $('[data-action="import_content"]').is(':checked'),
			import_pages: $('[data-action="import_pages"]').is(':checked'),
			import_opts: $('[data-action="import_opts"]').is(':checked'),
			import_widgets: $('[data-action="import_widgets"]').is(':checked'),
			clean_up: $('[data-action="clean_up"]').is(':checked'),
			plugins: [],
		};

		plugins.each(function () {
			const pluginCheckbox = $(this).find('input[type="checkbox"]');
			if (pluginCheckbox.is(':checked') && !pluginCheckbox.is(':disabled')) {
				settings.plugins.push(pluginCheckbox.val());
			}
		});

		self.handleAjaxImport(settings);
	};

	/** import */
	Module.runImportPluginContent = function (settings, currentStep, completeStep, errorStep, closeBtn) {
		const self = this;

		$.ajax({
			type: 'POST',
			async: true,
			dataType: 'json',
			url: self.globalConfigs.ajaxUrl,
			data: {
				action: 'rb_importer_plugin',
				settings: settings,
				_nonce: self.globalConfigs._rbNonce,
			},
			success: function () {
				self.runImportContent(settings, currentStep, completeStep, errorStep, closeBtn);
			},
			error: function () {
				currentStep.removeClass('activated-step');
				errorStep.addClass('activated-step');
				if (self.progressInterval) {
					clearInterval(self.progressInterval);
					self.progressInterval = null;
				}
			},
		});
	};

	Module.runImportContent = function (settings, currentStep, completeStep, errorStep, closeBtn) {
		const self = this;
		$.ajax({
			type: 'POST',
			async: true,
			dataType: 'json',
			url: self.globalConfigs.ajaxUrl,
			data: {
				action: 'rb_importer',
				settings: settings,
				_nonce: self.globalConfigs._rbNonce,
			},
			success: function (response) {
				currentStep.removeClass('activated-step');
				if (response && response.match(/Have fun!/gi)) {
					completeStep.addClass('activated-step');
				} else {
					errorStep.addClass('activated-step');
				}
			},
			error: function (xhr, status, error) {
				currentStep.removeClass('activated-step');
				if (xhr.responseText && xhr.responseText.match(/Have fun!/gi)) {
					completeStep.addClass('activated-step');
				} else {
					errorStep.addClass('activated-step');
				}
			},
			complete: function () {
				self.isAjaxProgressing = false;
				closeBtn.removeClass('disabled');
				if (self.progressInterval) {
					clearInterval(self.progressInterval);
					self.progressInterval = null;
				}
			},
		});
	};

	Module.handleAjaxImport = function (settings) {
		const self = this;
		const currentStep = $('#rb-importer .activated-step');
		const completeStep = $('#rb-importer .rb-step-complete');
		const errorStep = $('#rb-importer .rb-step-error');
		const closeBtn = $('#rb-importer .rb-close-import');

		if (self.isAjaxProgressing) return;

		self.getImporterProgress();
		self.isAjaxProgressing = true;
		if (settings.plugins && Array.isArray(settings.plugins) && settings.plugins.length > 0) {
			self.runImportPluginContent(settings, currentStep, completeStep, errorStep, closeBtn);
		} else {
			self.runImportContent(settings, currentStep, completeStep, errorStep, closeBtn);
		}
	};

	Module.getImporterProgress = function () {
		const self = this;

		const progressLabel = $('#rb-importer .rb-import-progress-label');
		const progressPercent = $('#rb-importer .rb-import-progress-percent');
		const indicator = $('#rb-importer .rb-import-progress-indicator');

		self.progressInterval = setInterval(function () {
			$.ajax({
				type: 'POST',
				async: true,
				dataType: 'json',
				url: self.globalConfigs.ajaxUrl,
				data: {
					action: 'rb_import_progress',
					_nonce: self.globalConfigs._rbNonce,
				},
				success: function (response) {
					if (response && response.success && response.data) {
						progressLabel.html(response.data.label);
						progressPercent.html(response.data.percent + '%');
						indicator.css('width', response.data.percent + '%');
					}
				},
			});
		}, 3000);
	};

	/** delete font project */
	Module.deleteFontProject = function () {
		const self = this;
		const deleteButton = $('#delete-project-id');
		const messenger = $('.rb-response-info');

		deleteButton.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			if (self.isAjaxProgressing) return;
			const confirm = window.confirm(self.globalConfigs.confirmDeleteAdobeFont);
			if (confirm === false) {
				return;
			}

			deleteButton.addClass('disabled');
			self.isAjaxProgressing = true;

			$.ajax({
				type: 'POST',
				async: true,
				dataType: 'json',
				url: self.globalConfigs.ajaxUrl,
				data: {
					action: 'rb_adobef_delete',
					_nonce: self.globalConfigs._rbNonce,
				},
				success: function (response) {
					response = JSON.parse(JSON.stringify(response));
					if ('undefined' != typeof response.data) {
						messenger.html('<p class="info-success">' + response.data + '</p>').removeClass('is-hidden');
					}
					setTimeout(function () {
						location.reload();
					}, 1000);
				},
				error: function (xhr, status, error) {
					deleteButton.text(self.globalConfigs.error);
					if (xhr.responseJSON && xhr.responseJSON.data) {
						messenger.html(xhr.responseJSON.data).removeClass('is-hidden');
					}
				},
				complete: function () {
					self.isAjaxProgressing = false;
				},
			});
		});
	};

	/** update font project */
	Module.updateFontProject = function () {
		const self = this;
		const editBtn = $('#rb-edit-project-id');
		const submitBtn = $('#submit-project-id');
		const projectID = $('#rb-project-id');
		const messenger = $('.rb-response-info');
		const loading = $('.rb-loading');

		editBtn.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();
			$(this).remove();
			projectID.prop('readonly', false);
			submitBtn.removeClass('is-hidden');
		});

		submitBtn.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			if (self.isAjaxProgressing) return;

			self.setButtonWidth(submitBtn);
			submitBtn.addClass('disabled');
			self.isAjaxProgressing = true;
			loading.fadeIn(300).removeClass('is-hidden');

			$.ajax({
				type: 'POST',
				async: true,
				dataType: 'json',
				url: self.globalConfigs.ajaxUrl,
				data: {
					action: 'rb_adobef_update',
					_nonce: self.globalConfigs._rbNonce,
					projectID: projectID.val(),
				},
				success: function (response) {
					if (response.data) {
						messenger.html('<p class="info-success">' + response.data + '</p>').removeClass('is-hidden');
						submitBtn.text(self.globalConfigs.reload);
						setTimeout(function () {
							location.reload();
						}, 1000);
					}
				},
				error: function (xhr, status, error) {
					submitBtn.text(self.globalConfigs.error);
					if (xhr.responseJSON && xhr.responseJSON.data) {
						messenger.html(xhr.responseJSON.data).removeClass('is-hidden');
					}
				},
				complete: function () {
					self.isAjaxProgressing = false;
				},
			});
		});
	};

	/** delete GTM tag */
	Module.deleteGTMTag = function () {
		const self = this;
		const button = $('#rb-gtm-delete');
		const messenger = $('.rb-response-info');
		const loading = button.find('.rb-loading');

		button.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			const confirm = window.confirm(self.globalConfigs.confirmDeleteGA);
			if (confirm === false) {
				return;
			}

			if (self.isAjaxProgressing) return;
			self.setButtonWidth(button);
			button.addClass('disabled');
			loading.fadeIn(300).removeClass('is-hidden');

			self.isAjaxProgressing = true;

			$.ajax({
				type: 'POST',
				async: true,
				dataType: 'json',
				url: self.globalConfigs.ajaxUrl,
				data: {
					action: 'rb_gtm_delete',
					_nonce: self.globalConfigs._rbNonce,
				},
				success: function (response) {
					response = JSON.parse(JSON.stringify(response));
					if ('undefined' != typeof response.data) {
						messenger.html('<p class="info-success">' + response.data + '</p>').removeClass('is-hidden');
					}
					button.text(self.globalConfigs.reload);
					setTimeout(function () {
						location.reload();
					}, 1000);
				},
				error: function (xhr, status, error) {
					button.text(self.globalConfigs.error);
					if (xhr.responseJSON && xhr.responseJSON.data) {
						messenger.html(xhr.responseJSON.data).removeClass('is-hidden');
					}
				},
				complete: function () {
					self.isAjaxProgressing = false;
				},
			});
		});
	};

	/** add tags */
	Module.addGTMTag = function () {
		const self = this;
		const button = $('#rb-gtm-submit');
		const messenger = $('.rb-response-info');
		const loading = button.find('.rb-loading');

		button.on('click', function (e) {
			e.preventDefault();
			e.stopPropagation();

			if (self.isAjaxProgressing) {
				return;
			}

			self.setButtonWidth(button);
			button.addClass('disabled');
			self.isAjaxProgressing = true;
			loading.fadeIn(300).removeClass('is-hidden');

			$.ajax({
				type: 'POST',
				async: true,
				dataType: 'json',
				url: self.globalConfigs.ajaxUrl,
				data: {
					action: 'rb_gtm_add',
					gtmID: $('#rb-gtm-input').val(),
					gtagID: $('#rb-gtag-input').val(),
					_nonce: self.globalConfigs._rbNonce,
				},
				success: function (response) {
					response = JSON.parse(JSON.stringify(response));
					if ('undefined' != typeof response.data) {
						messenger.html('<p class="info-success">' + response.data + '</p>').removeClass('is-hidden');
					}
					button.text(self.globalConfigs.reload);
					setTimeout(function () {
						location.reload();
					}, 1000);
				},
				error: function (xhr, status, error) {
					button.removeClass('disabled');
					if (xhr.responseJSON && xhr.responseJSON.data) {
						messenger.html(xhr.responseJSON.data).removeClass('is-hidden');
					}
				},
				complete: function () {
					loading.addClass('is-hidden');
					self.isAjaxProgressing = false;
				},
			});
		});
	};

	return Module;
})(RB_ADMIN_CORE || {}, jQuery);

jQuery(document).ready(function () {
	RB_ADMIN_CORE.init();
});
