<?php
/** Don't load directly */
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Rb_Translation_Init', false ) ) {
	class Rb_Translation_Init {

		private static $instance;
		private static $nonce = 'foxiz-admin';

		public static function get_instance() {

			if ( null === self::$instance ) {
				return new self();
			}

			return self::$instance;
		}

		public function __construct() {

			self::$instance = $this;

			add_action( 'wp_ajax_rb_fetch_translation', [ $this, 'reload_translation' ] );
			add_action( 'wp_ajax_rb_auto_translation', [ $this, 'auto_translation' ] );
			add_action( 'wp_ajax_rb_update_translation', [ $this, 'update_translation' ] );
			add_action( 'wp_ajax_rb_export_translation', [ $this, 'export_translation' ] );
			add_action( 'wp_ajax_rb_import_translation', [ $this, 'import_translation' ] );
			add_action( 'wp_ajax_rb_clear_translation', [ $this, 'clear_translation' ] );
		}

		public function reload_translation() {

			$nonce = ( isset( $_POST['_nonce'] ) ) ? sanitize_key( $_POST['_nonce'] ) : '';

			if ( empty( $nonce ) || false === wp_verify_nonce( $nonce, self::$nonce ) ) {
				wp_send_json_error( esc_html__( 'Nonce validation failed. Please try again.', 'foxiz-core' ), 400 );

				wp_die();
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( esc_html__( 'Sorry, you are not allowed to perform this action.', 'foxiz-core' ), 403 );

				wp_die();
			}

			delete_option( 'rb_translation_data' );
			wp_send_json_success( esc_html__( 'Completed', 'foxiz-core' ) );
		}

		public function update_translation() {

			$nonce = ( isset( $_POST['_nonce'] ) ) ? sanitize_key( $_POST['_nonce'] ) : '';
			if ( empty( $nonce ) || false === wp_verify_nonce( $nonce, self::$nonce ) ) {
				wp_send_json_error( esc_html__( 'Nonce validation failed. Please try again.', 'foxiz-core' ), 400 );

				wp_die();
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( esc_html__( 'Sorry, you are not allowed to perform this action.', 'foxiz-core' ), 403 );

				wp_die();
			}

			$data = $_POST;

			unset( $data['_nonce'], $data['action'] );

			$data = array_map( 'sanitize_text_field', array_map( 'stripslashes', $data ) );
			update_option( 'rb_translated_data', $data );

			wp_send_json_success();

			wp_die();
		}


		public function export_translation() {

			$nonce = ( isset( $_POST['_nonce'] ) ) ? sanitize_key( $_POST['_nonce'] ) : '';
			if ( empty( $nonce ) || false === wp_verify_nonce( $nonce, self::$nonce ) ) {
				wp_send_json_error( esc_html__( 'Nonce validation failed. Please try again.', 'foxiz-core' ), 400 );

				wp_die();
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( esc_html__( 'Sorry, you are not allowed to perform this action.', 'foxiz-core' ), 403 );

				wp_die();
			}

			$content = rbSubPageTranslation::get_instance()->export_data();

			wp_send_json_success( $content );

			wp_die();
		}


		public function import_translation() {

			// Check nonce for security
			$nonce = isset( $_POST['_nonce'] ) ? sanitize_key( $_POST['_nonce'] ) : '';
			if ( empty( $nonce ) || false === wp_verify_nonce( $nonce, self::$nonce ) ) {
				wp_send_json_error(
					esc_html__( 'Nonce validation failed. Please try again.', 'foxiz-core' ),
					400
				);
			}

			// Check user capabilities
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error(
					esc_html__( 'Sorry, you are not allowed to perform this action.', 'foxiz-core' ),
					403
				);
			}

			// Ensure a file was uploaded
			if ( empty( $_FILES['translation_file']['name'] ) ) {
				wp_send_json_error( [ 'message' => __( 'No file uploaded.', 'foxiz-core' ) ], 400 );
			}

			// Use WordPress wp_handle_upload to safely process the uploaded file
			require_once ABSPATH . 'wp-admin/includes/file.php';

			$overrides = [
				'test_form'                => false,          // Disable form submission check
				'mimes'                    => [ 'json' => 'application/json' ], // Only allow JSON files
				'unique_filename_callback' => null,
			];

			$upload = wp_handle_upload( $_FILES['translation_file'], $overrides );

			// Check for upload errors
			if ( isset( $upload['error'] ) ) {
				wp_send_json_error( [ 'message' => $upload['error'] ], 400 );
			}

			$uploaded_file = $upload['file']; // Temporary file path

			// Use WP_Filesystem to read the uploaded file
			global $wp_filesystem;
			if ( empty( $wp_filesystem ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
				WP_Filesystem();
			}

			if ( ! $wp_filesystem->exists( $uploaded_file ) ) {
				wp_send_json_error( [ 'message' => __( 'Uploaded file not found.', 'foxiz-core' ) ], 400 );
			}

			$json = $wp_filesystem->get_contents( $uploaded_file );

			// Delete temporary file after reading
			wp_delete_file( $uploaded_file );

			// Check if file reading failed
			if ( false === $json ) {
				wp_send_json_error( [ 'message' => __( 'Failed to read uploaded file.', 'foxiz-core' ) ], 400 );
			}

			// Decode JSON content
			$data = json_decode( $json, true );

			// Validate JSON format
			if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $data ) ) {
				wp_send_json_error( [ 'message' => __( 'Invalid JSON format.', 'foxiz-core' ) ], 400 );
			}

			// Run Import
			rbSubPageTranslation::get_instance()->import_data( $data );

			// Return success response
			wp_send_json_success( [ 'message' => __( 'Imported successfully.', 'foxiz-core' ) ] );

			wp_die();
		}

		public function auto_translation() {

			// Verify nonce
			$nonce = isset( $_POST['_nonce'] ) ? sanitize_key( $_POST['_nonce'] ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, self::$nonce ) ) {
				wp_send_json_error(
					[
						'message' => esc_html__( 'Nonce validation failed. Please try again.', 'foxiz-core' ),
					],
					400
				);
			}

			// Check user capability
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error(
					[
						'message' => esc_html__( 'Sorry, you are not allowed to perform this action.', 'foxiz-core' ),
					],
					403
				);
			}

			// Determine current site language
			$locale = str_replace( '-', '_', get_locale() );

			$base_url = 'https://assets.themeruby.com/foxiz-translation/';
			$urls     = [];

			$urls[] = "{$base_url}{$locale}.json";

			$lang = strtolower( substr( $locale, 0, 2 ) );

			if ( $lang && $lang !== $locale ) {
				$urls[] = "{$base_url}{$lang}.json";
			}

			$translation_data = null;
			$last_error       = '';

			// Fetch JSON with fallback
			foreach ( $urls as $url ) {
				$response = wp_remote_get(
					$url,
					[
						'timeout'   => 10,
						'sslverify' => true,
					]
				);

				if ( is_wp_error( $response ) ) {
					$last_error = $response->get_error_message();
					continue;
				}

				$code = wp_remote_retrieve_response_code( $response );
				$body = wp_remote_retrieve_body( $response );

				if ( $code !== 200 || empty( $body ) ) {
					$last_error = esc_html__(
						'It appears that no translation is currently available for your language. Please contact our support team, and we’ll be happy to add it for you.',
						'foxiz-core'
					);
					continue;
				}

				$json = json_decode( $body, true );

				if ( json_last_error() === JSON_ERROR_NONE && is_array( $json ) ) {
					$translation_data = $json;
					break; // Stop when first valid file found
				}

				$last_error = esc_html__( 'Invalid JSON format.', 'foxiz-core' );
			}

			if ( empty( $translation_data ) ) {
				wp_send_json_error(
					[
						'message' => $last_error,
					],
					404
				);
			}

			// Import translation
			rbSubPageTranslation::get_instance()->import_data( $translation_data );

			// Send success response
			wp_send_json_success(
				[
					'message' => esc_html__( 'Automatic translation completed successfully.', 'foxiz-core' ),
				]
			);

			wp_die();
		}

		public function clear_translation() {

			$nonce = ( isset( $_POST['_nonce'] ) ) ? sanitize_key( $_POST['_nonce'] ) : '';

			if ( empty( $nonce ) || false === wp_verify_nonce( $nonce, self::$nonce ) ) {
				wp_send_json_error( esc_html__( 'Nonce validation failed. Please try again.', 'foxiz-core' ), 400 );

				wp_die();
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( esc_html__( 'Sorry, you are not allowed to perform this action.', 'foxiz-core' ), 403 );

				wp_die();
			}

			delete_option( 'rb_translated_data' );

			wp_send_json_success();

			wp_die();
		}
	}
}

/** load */
Rb_Translation_Init::get_instance();
