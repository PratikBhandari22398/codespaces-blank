<?php
/**
 * Rate Limiting Utility.
 *
 * Self-contained rate limiter using APCu or wp_cache (Redis/Memcached).
 * Optional transient (database) fallback can be enabled in theme settings.
 * Skips rate limiting if no cache available to avoid unnecessary overhead.
 *
 * Usage:
 *   if ( class_exists( 'Foxiz_Rate_Limit' ) && ! Foxiz_Rate_Limit::check( 'action_name' ) ) {
 *       // Rate limited - return error
 *   }
 *
 * @package Foxiz_Core
 * @since 2.7.5
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Foxiz_Rate_Limit
 *
 * Static utility class for rate limiting.
 */
class Foxiz_Rate_Limit {

	/**
	 * Cache driver being used.
	 *
	 * @var string|null
	 */
	private static $driver = null;

	/**
	 * Check if request is within rate limit.
	 *
	 * @param string $action Action identifier (e.g., 'reaction', 'bookmark').
	 * @param int    $limit  Max requests allowed (default: 60).
	 * @param int    $window Time window in seconds (default: 60).
	 *
	 * @return bool True if allowed, false if rate limited.
	 */
	public static function check( $action, $limit = 60, $window = 60 ) {
		$driver = self::get_driver();

		// Skip rate limiting if no cache available.
		if ( 'none' === $driver ) {
			return true;
		}

		$ip  = foxiz_get_client_ip();
		$key = 'fxrl_' . md5( $action . '_' . $ip );

		switch ( $driver ) {
			case 'apcu':
				return self::check_apcu( $key, $limit, $window );
			case 'wp_cache':
				return self::check_wp_cache( $key, $limit, $window );
			case 'transient':
				return self::check_transient( $key, $limit, $window );
			default:
				return true;
		}
	}

	/**
	 * Get or detect cache driver.
	 *
	 * Works in both AJAX and REST API contexts by using multiple detection methods.
	 *
	 * @return string Driver name: 'apcu', 'wp_cache', 'transient', or 'none'.
	 */
	private static function get_driver() {
		if ( null !== self::$driver ) {
			return self::$driver;
		}

		// APCu is fastest (sub-microsecond, local memory).
		if ( function_exists( 'apcu_fetch' ) && filter_var( ini_get( 'apc.enabled' ), FILTER_VALIDATE_BOOLEAN ) ) {
			self::$driver = 'apcu';
			return self::$driver;
		}

		// Check for external object cache using multiple methods.
		if ( self::has_external_object_cache() ) {
			self::$driver = 'wp_cache';
			return self::$driver;
		}

		// No fast cache available - check if transient fallback is enabled.
		if ( function_exists( 'foxiz_get_option' ) && foxiz_get_option( 'rate_limit_transient' ) ) {
			self::$driver = 'transient';
			return self::$driver;
		}

		// No cache and transient fallback disabled.
		self::$driver = 'none';
		return self::$driver;
	}

	/**
	 * Check if external object cache is available.
	 *
	 * Uses multiple detection methods to work in AJAX and REST API contexts.
	 *
	 * @return bool True if external object cache is available.
	 */
	private static function has_external_object_cache() {
		// First, ensure wp_cache functions exist.
		if ( ! function_exists( 'wp_cache_get' ) || ! function_exists( 'wp_cache_set' ) ) {
			return false;
		}

		// Method 1: Check WordPress function (may not be available in early AJAX).
		if ( function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache() ) {
			return true;
		}

		// Method 2: Check global variable directly.
		global $_wp_using_ext_object_cache;
		if ( ! empty( $_wp_using_ext_object_cache ) ) {
			return true;
		}

		// Method 3: Check for object-cache.php drop-in file.
		if ( defined( 'WP_CONTENT_DIR' ) && file_exists( WP_CONTENT_DIR . '/object-cache.php' ) ) {
			return true;
		}

		// Method 4: Check for Redis constants (common Redis plugins).
		if ( defined( 'WP_REDIS_HOST' ) || defined( 'WP_REDIS_SERVERS' ) || defined( 'WP_REDIS_CLUSTER' ) ) {
			return true;
		}

		// Method 5: Check for Memcached constants.
		if ( defined( 'MEMCACHED_SERVERS' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Check rate limit using APCu (fastest).
	 *
	 * @param string $key    Cache key.
	 * @param int    $limit  Request limit.
	 * @param int    $window Time window in seconds.
	 *
	 * @return bool True if allowed.
	 */
	private static function check_apcu( $key, $limit, $window ) {
		$success = false;
		$count   = apcu_fetch( $key, $success );

		if ( ! $success ) {
			apcu_store( $key, 1, $window );
			return true;
		}

		if ( $count >= $limit ) {
			return false;
		}

		apcu_inc( $key );
		return true;
	}

	/**
	 * Check rate limit using wp_cache (Redis/Memcached).
	 *
	 * @param string $key    Cache key.
	 * @param int    $limit  Request limit.
	 * @param int    $window Time window in seconds.
	 *
	 * @return bool True if allowed.
	 */
	private static function check_wp_cache( $key, $limit, $window ) {
		// Safety check for wp_cache functions.
		if ( ! function_exists( 'wp_cache_get' ) || ! function_exists( 'wp_cache_set' ) ) {
			return true;
		}

		$count = wp_cache_get( $key, 'foxiz_rate_limit' );

		if ( false === $count ) {
			wp_cache_set( $key, 1, 'foxiz_rate_limit', $window );
			return true;
		}

		if ( $count >= $limit ) {
			return false;
		}

		// wp_cache_incr may not exist in all implementations.
		if ( function_exists( 'wp_cache_incr' ) ) {
			wp_cache_incr( $key, 1, 'foxiz_rate_limit' );
		} else {
			wp_cache_set( $key, $count + 1, 'foxiz_rate_limit', $window );
		}

		return true;
	}

	/**
	 * Check rate limit using transients (database fallback).
	 *
	 * Note: This is slower than APCu/Redis as it uses the database.
	 * Only use when no fast cache is available and you accept the DB overhead.
	 *
	 * @param string $key    Cache key.
	 * @param int    $limit  Request limit.
	 * @param int    $window Time window in seconds.
	 *
	 * @return bool True if allowed.
	 */
	private static function check_transient( $key, $limit, $window ) {
		$count = get_transient( $key );

		if ( false === $count ) {
			set_transient( $key, 1, $window );
			return true;
		}

		if ( (int) $count >= $limit ) {
			return false;
		}

		// Increment counter.
		set_transient( $key, (int) $count + 1, $window );
		return true;
	}

	/**
	 * Send rate limit exceeded response and exit.
	 *
	 * @param string $message Optional custom message.
	 */
	public static function send_error( $message = '' ) {
		if ( empty( $message ) ) {
			$message = __( 'Too many requests. Please try again later.', 'foxiz-core' );
		}

		status_header( 429 );
		header( 'Retry-After: 60' );
		header( 'Content-Type: application/json; charset=utf-8' );

		wp_send_json_error(
			[
				'code'    => 'rate_limited',
				'message' => esc_html( $message ),
			],
			429
		);
	}
}
