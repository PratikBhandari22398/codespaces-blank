<?php
/** Don't load directly */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'foxiz_render_list_style' ) ) {
	function foxiz_render_list_style( $attributes, $content ) {

		$icon        = ! empty( $attributes['icon'] ) ? preg_replace( '/[^a-fA-F0-9]/', '', $attributes['icon'] ) : '';
		$emoji       = ! empty( $attributes['emoji'] ) ? $attributes['emoji'] : '';
		$desktopSize = ! empty( $attributes['desktopSize'] ) ? absint( $attributes['desktopSize'] ) : '';
		$tabletSize  = ! empty( $attributes['tabletSize'] ) ? absint( $attributes['tabletSize'] ) : '';
		$mobileSize  = ! empty( $attributes['mobileSize'] ) ? absint( $attributes['mobileSize'] ) : '';
		$color       = ! empty( $attributes['color'] ) ? sanitize_hex_color( $attributes['color'] ) : '';
		$darkColor   = ! empty( $attributes['darkColor'] ) ? sanitize_hex_color( $attributes['darkColor'] ) : '';
		$spacing     = ! empty( $attributes['spacing'] ) ? absint( $attributes['spacing'] ) : '';

		$wrapperClassName = 'list-style-element';
		if ( $emoji ) {
			$wrapperClassName .= ' is-emoji';
		} else {
			$wrapperClassName .= ' is-icon';
		}

		$styleAttribute = '';

		// Convert hex icon code to actual unicode character (e.g., 'e958' -> '')
		// This bypasses WP sanitization since it's a real character, not an escape sequence
		if ( $emoji ) {
			$styleAttribute .= '--icon-code: "' . esc_attr( $emoji ) . '"; ';
		} elseif ( ! empty( $icon ) ) {
			$icon_char       = mb_chr( hexdec( $icon ), 'UTF-8' );
			$styleAttribute .= '--icon-code: "' . $icon_char . '"; ';
		}

		if ( $desktopSize ) {
			$styleAttribute .= '--desktop-icon-size: ' . $desktopSize . 'px; ';
		}
		if ( $tabletSize ) {
			$styleAttribute .= '--tablet-icon-size: ' . $tabletSize . 'px; ';
		}
		if ( $mobileSize ) {
			$styleAttribute .= '--mobile-icon-size: ' . $mobileSize . 'px; ';
		}
		if ( $spacing ) {
			$styleAttribute .= '--item-spacing: ' . $spacing . 'px; ';
		}
		if ( $color ) {
			$styleAttribute .= '--icon-color: ' . $color . '; ';
		}
		if ( $darkColor ) {
			$styleAttribute .= '--dark-icon-color: ' . $darkColor . '; ';
		}

		return '<div ' . get_block_wrapper_attributes(
			[
				'class' => $wrapperClassName,
				'style' => $styleAttribute,
			]
		) . '>' . $content . '</div>';
	}
}
