<?php
/** Don't load directly */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'foxiz_accordion_item' ) ) {
	function foxiz_accordion_item( $attributes, $content ) {

		if ( empty( $content ) ) {
			return false;
		}

		if ( empty( $attributes['heading'] ) ) {
			$attributes['heading'] = '';
		}

		if ( empty( $attributes['faqSchema'] ) ) {
			$attributes['faqSchema'] = false;
		}

		if ( empty( $attributes['headingTag'] ) ) {
			$attributes['headingTag'] = 'h3';
		}

		$title_classes = 'accordion-title gb-heading';
		if ( empty( $attributes['tocAdded'] ) ) {
			$title_classes .= ' none-toc';
		}

		// Collect data for JSON-LD schema if faqSchema is enabled

		if ( $attributes['faqSchema'] ) {

			global $foxiz_faq_schema;
			if ( ! isset( $foxiz_faq_schema ) ) {
				$foxiz_faq_schema = [];
			}

			// Add FAQ item to schema array
			$foxiz_faq_schema[] = [
					'@type'          => 'Question',
					'name'           => wp_strip_all_tags( $attributes['heading'] ),
					'acceptedAnswer' => [
							'@type' => 'Answer',
							'text'  => wp_strip_all_tags( $content ),
					],
			];
		}

		ob_start();
		?>
		<div <?php echo get_block_wrapper_attributes( [ 'class' => 'gb-accordion-item' ] ); ?>>
			<div class="accordion-item-header">
				<?php echo '<' . $attributes['headingTag'] . ' class="' . $title_classes . '">' . $attributes['heading'] . '</' . $attributes['headingTag'] . '>'; ?>
				<i class="rbi rbi-angle-down gb-heading"></i>
			</div>
			<div class="accordion-item-content rb-text">
				<?php echo $content; ?>
			</div>
		</div>
		<?php

		if ( $attributes['faqSchema'] && ! has_action( 'wp_footer', 'foxiz_output_faq_schema' ) ) {
			add_action( 'wp_footer', 'foxiz_output_faq_schema', 40 );
		}

		// Return the buffered HTML
		return ob_get_clean();
	}
}

if ( ! function_exists( 'foxiz_output_faq_schema' ) ) {
	function foxiz_output_faq_schema() {
		global $foxiz_faq_schema;

		// Check if schema data exists
		if ( ! empty( $foxiz_faq_schema ) ) {
			// Define the FAQPage schema structure
			$schema = [
					'@context'   => 'https://schema.org',
					'@type'      => 'FAQPage',
					'mainEntity' => $foxiz_faq_schema,
			];
			?>
			<script type="application/ld+json"><?php echo wp_json_encode( $schema, JSON_UNESCAPED_UNICODE ); ?></script>
			<?php
			$foxiz_faq_schema = [];
		}
	}
}
