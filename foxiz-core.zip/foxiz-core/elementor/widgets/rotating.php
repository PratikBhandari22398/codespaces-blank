<?php

namespace foxizElementor\Widgets;
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Widget_Base;
use foxizElementorControl\Options;

/**
 * Class Rotating_Words
 *
 * @package foxizElementor\Widgets
 */
class Rotating_Words extends Widget_Base {

	public function get_name() {
		return 'foxiz-rotating-words';
	}

	public function get_title() {
		return esc_html__( 'Foxiz - Rotating Words', 'foxiz-core' );
	}

	public function get_icon() {
		return 'eicon-animation-text';
	}

	public function get_keywords() {
		return [ 'foxiz', 'rotating', 'words', 'animation', 'text' ];
	}

	public function get_categories() {
		return [ 'foxiz_element' ];
	}

	public function get_style_depends() {
		return [ 'foxiz-rotating-words' ];
	}

	public function get_script_depends() {
		return [ 'foxiz-rotating-words' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
				'content_section',
				[
						'label' => esc_html__( 'Content Settings', 'foxiz-core' ),
						'tab'   => Controls_Manager::TAB_CONTENT,
				]
		);
		$this->add_control(
				'html_tag',
				[
						'label'   => esc_html__( 'Heading HTML Tag', 'foxiz-core' ),
						'type'    => Controls_Manager::SELECT,
						'options' => Options::heading_html_dropdown( false ),
						'default' => 'h2',
				]
		);
		$this->add_control(
				'beginning_text',
				[
						'label'       => esc_html__( 'Beginning Text', 'foxiz-core' ),
						'type'        => Controls_Manager::TEXTAREA,
						'ai'          => [ 'active' => false ],
						'rows'        => 2,
						'description' => esc_html__( 'Enter the text to display before the rotating words.', 'foxiz-core' ),
						'default'     => 'THE BEST',
				]
		);
		$repeater = new Repeater();
		$repeater->add_control(
				'word',
				[
						'label'       => esc_html__( 'Word', 'foxiz-core' ),
						'description' => esc_html__( 'Enter a word to rotate.', 'foxiz-core' ),
						'type'        => Controls_Manager::TEXT,
						'ai'          => [ 'active' => false ],
				]
		);
		$this->add_control(
				'dynamic_words',
				[
						'label'       => esc_html__( 'Rotating Words', 'foxiz-core' ),
						'type'        => Controls_Manager::REPEATER,
						'fields'      => $repeater->get_controls(),
						'default'     => [
								[ 'word' => 'NEWS' ],
								[ 'word' => 'MAGAZINE' ],
								[ 'word' => 'BLOG' ],
						],
						'title_field' => '{{{ word }}}',
				]
		);
		$this->add_control(
				'end_text',
				[
						'label'       => esc_html__( 'End Text', 'foxiz-core' ),
						'type'        => Controls_Manager::TEXTAREA,
						'ai'          => [ 'active' => false ],
						'rows'        => 2,
						'description' => esc_html__( 'Enter the text to display after the rotating words.', 'foxiz-core' ),
						'default'     => 'WORDPRESS THEME.',
				]
		);
		$this->end_controls_section();
		$this->start_controls_section(
				'style_section',
				[
						'label' => esc_html__( 'Style', 'foxiz-core' ),
						'tab'   => Controls_Manager::TAB_STYLE,
				]
		);
		$this->add_responsive_control(
				'beginning_wrap',
				[
						'label'     => esc_html__( 'End Text Wrap', 'foxiz-core' ),
						'type'      => Controls_Manager::CHOOSE,
						'options'   => [
								'inline-block' => [
										'title' => esc_html__( 'No Wrap', 'foxiz-core' ),
										'icon'  => 'eicon-flex eicon-nowrap',
								],
								'block'        => [
										'title' => esc_html__( 'Wrap', 'foxiz-core' ),
										'icon'  => 'eicon-flex eicon-wrap',
								],
						],
						'default'   => '',
						'selectors' => [ '{{WRAPPER}} .prefix-text' => 'display: {{VALUE}};' ],
				]
		);
		$this->add_responsive_control(
				'end_wrap',
				[
						'label'     => esc_html__( 'End Text Wrap', 'foxiz-core' ),
						'type'      => Controls_Manager::CHOOSE,
						'options'   => [
								'inline-block' => [
										'title' => esc_html__( 'No Wrap', 'foxiz-core' ),
										'icon'  => 'eicon-flex eicon-nowrap',
								],
								'block'        => [
										'title' => esc_html__( 'Wrap', 'foxiz-core' ),
										'icon'  => 'eicon-flex eicon-wrap',
								],
						],
						'default'   => '',
						'selectors' => [ '{{WRAPPER}} .suffix-text' => 'display: {{VALUE}};' ],
				]
		);
		$this->add_responsive_control(
				'title_align',
				[
						'label'     => esc_html__( 'Alignment', 'foxiz-core' ),
						'type'      => Controls_Manager::CHOOSE,
						'options'   => [
								'left'   => [
										'title' => esc_html__( 'Left', 'foxiz-core' ),
										'icon'  => 'eicon-text-align-left',
								],
								'center' => [
										'title' => esc_html__( 'Center', 'foxiz-core' ),
										'icon'  => 'eicon-text-align-center',
								],
								'right'  => [
										'title' => esc_html__( 'Right', 'foxiz-core' ),
										'icon'  => 'eicon-text-align-right',
								],
						],
						'default'   => '',
						'selectors' => [ '{{WRAPPER}}' => 'text-align: {{VALUE}};' ],
				]
		);


		$this->add_control(
				'duration',
				[
						'label'       => esc_html__( 'Cycle Duration (ms)', 'foxiz-core' ),
						'type'        => Controls_Manager::NUMBER,
						'description' => esc_html__( 'Set the duration (in milliseconds) for each word cycle.', 'foxiz-core' ),
						'default'     => 3000,
				]
		);
		$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
						'label'    => esc_html__( 'Title Font', 'foxiz-core' ),
						'name'     => 'title_font',
						'selector' => '{{WRAPPER}} .rotating-words',
				]
		);
		$this->add_control(
				'title_color',
				[
						'label'     => esc_html__( 'Title Color', 'foxiz-core' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
								'{{WRAPPER}}' => '--title-color: {{VALUE}};',
						],
				]
		);
		$this->add_control(
				'rotating_color',
				[
						'label'     => esc_html__( 'Rotating Color', 'foxiz-core' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
								'{{WRAPPER}}' => '--rotating-color: {{VALUE}};',
						],
				]
		);
		$this->add_control(
				'dark_title_color',
				[
						'label'     => esc_html__( 'Dark Mode - Title Color', 'foxiz-core' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => [
								'[data-theme="dark"] {{WRAPPER}}' => '--title-color: {{VALUE}};',
						],
				]
		);
		$this->add_control(
				'dark_rotating_color',
				[
						'label'     => esc_html__( 'Rotating Color', 'foxiz-core' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
								'[data-theme="dark"] {{WRAPPER}}' => '--rotating-color: {{VALUE}};',
						],
				]
		);
		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings();
		$html_tag = ! empty( $settings['html_tag'] ) ? $settings['html_tag'] : 'h2';
		?>
		<<?php echo esc_attr( $html_tag ); ?> class="rotating-words" data-duration="<?php echo esc_attr( $settings['duration'] ); ?>">
		<?php if ( ! empty( $settings['beginning_text'] ) ) : ?>
			<span class="prefix-text">
                <span class="word"><?php echo esc_html( $settings['beginning_text'] ); ?></span>
         </span>
		<?php endif; ?>
		<span class="rotating-text">
            <?php foreach ( $settings['dynamic_words'] as $index => $item ) : ?>
	            <span class="word<?php echo $index === 0 ? ' active' : ''; ?>">
                    <span><?php echo esc_html( $item['word'] ); ?></span>
                </span>
            <?php endforeach; ?>
        </span>
		<?php if ( ! empty( $settings['end_text'] ) ) : ?>
			<span class="suffix-text">
                <span class="word"><?php echo esc_html( $settings['end_text'] ); ?></span>
         </span>
		<?php endif; ?>
		</<?php echo esc_attr( $html_tag ); ?>>
		<?php
	}
}