<?php
/**
 * Description tab
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/tabs/description.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @author      WooThemes
 * @package     WooCommerce/Templates
 * @version     2.0.0
 */

/** Don't load directly */
defined( 'ABSPATH' ) || exit;

global $post;
$heading = apply_filters( 'woocommerce_product_description_heading', esc_html__( 'Description', 'foxiz' ), 10 ); ?>
<div class="entry entry-content rbct clearfix">
	<?php the_content(); ?>
</div>
