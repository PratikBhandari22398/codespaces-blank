/**
 * RB Viewport Observer v2.3
 * High-performance viewport detection using IntersectionObserver
 *
 * @package foxiz
 * @version 2.3.0
 */
var RB_VIEWPORT_OBSERVER = (function (existing) {
    'use strict';

    if (existing && existing._initialized && existing._version === '2.3') {
        return existing;
    }

    var hasIO = 'IntersectionObserver' in window;
    var observers = {};
    var count = 0;
    var lastY = 0;
    var dir = 'down';
    var listening = false;
    var rafId = 0;
    var idNum = 0;
    var win = window;
    var doc = document;

    function getScrollY() {
        return win.pageYOffset || 0;
    }

    function onScroll() {
        if (!rafId) {
            rafId = requestAnimationFrame(function () {
                var y = getScrollY();
                var diff = y - lastY;
                if (diff > 5) dir = 'down';
                else if (diff < -5) dir = 'up';
                lastY = y;
                rafId = 0;
            });
        }
    }

    function startListening() {
        if (!listening && count > 0) {
            lastY = getScrollY();
            win.addEventListener('scroll', onScroll, { passive: true });
            listening = true;
        }
    }

    function stopListening() {
        if (listening && count === 0) {
            win.removeEventListener('scroll', onScroll);
            listening = false;
            if (rafId) {
                cancelAnimationFrame(rafId);
                rafId = 0;
            }
        }
    }

    function getEl(el) {
        return !el ? null : (el.nodeType ? el : (el[0] || null));
    }

    function parseOffset(offset, el) {
        if (typeof offset === 'function') offset = offset.call(el);

        if (typeof offset === 'number') {
            return { m: '0px 0px ' + offset + 'px 0px', v: offset, p: false };
        }

        if (typeof offset === 'string' && offset.indexOf('%') > -1) {
            var n = parseInt(offset, 10);
            var v = n > 100 ? n - 100 : (n >= 0 ? -(100 - n) : n);
            return { m: '0px 0px ' + v + '% 0px', v: v, p: true };
        }

        return { m: '0px', v: 0, p: false };
    }

    function makeCallback(id) {
        return function (entries) {
            var d = observers[id];
            if (!d) return;

            var e = entries[0];
            var was = d.inView;
            var now = e.isIntersecting;

            if (was === now) return;
            d.inView = now;

            var direction = now ? dir : (dir === 'down' ? 'up' : 'down');

            // Throttle continuous mode
            if (d.cont && now) {
                var t = Date.now();
                if (t - d.lastT < 100) return;
                d.lastT = t;
            }

            if (d.fn) {
                d.fn.call(d.ctx, direction);
            }

            if (d.once && direction === 'down') {
                unobserve(id);
            }
        };
    }

    function makeContext(id, el) {
        return {
            element: el,
            destroy: function () { unobserve(id); },
            reset: function () { resetState(id); }
        };
    }

    function observe(id, opts) {
        if (!hasIO || !opts || !opts.element) return null;

        var el = getEl(opts.element);
        if (!el) return null;

        if (!id) id = 'vo_' + (++idNum);
        if (observers[id]) unobserve(id);

        var p = parseOffset(opts.offset, el);
        var cb = makeCallback(id);
        var ctx = makeContext(id, opts.element);

        var io = new IntersectionObserver(cb, {
            root: null,
            rootMargin: p.m,
            threshold: 0
        });

        observers[id] = {
            io: io,
            el: el,
            fn: opts.handler,
            ctx: ctx,
            off: opts.offset,
            once: !!opts.once,
            cont: !!opts.continuous,
            m: p.m,
            val: p.v,
            pct: p.p,
            inView: false,
            lastT: 0
        };

        count++;
        startListening();
        io.observe(el);

        return id;
    }

    function unobserve(id) {
        var d = observers[id];
        if (d) {
            d.io.disconnect();
            d.io = d.el = d.fn = d.ctx = null;
            delete observers[id];
            count--;
            stopListening();
        }
    }

    function resetState(id) {
        var d = observers[id];
        if (d) {
            d.inView = false;
            d.lastT = 0;
        }
    }

    function refresh(id) {
        var d = observers[id];
        if (!d) return;

        if (!doc.body.contains(d.el)) {
            unobserve(id);
            return;
        }

        d.io.disconnect();

        var p = parseOffset(d.off, d.el);
        d.m = p.m;
        d.val = p.v;
        d.pct = p.p;

        var cb = makeCallback(id);
        var io = new IntersectionObserver(cb, {
            root: null,
            rootMargin: p.m,
            threshold: 0
        });

        io.observe(d.el);
        d.io = io;
        d.inView = false;
        d.lastT = 0;
    }

    function refreshAll() {
        var ids = Object.keys(observers);
        for (var i = 0, len = ids.length; i < len; i++) {
            refresh(ids[i]);
        }
    }

    function has(id) {
        return id in observers;
    }

    function getActiveIds() {
        return Object.keys(observers);
    }

    function destroyAll() {
        var ids = Object.keys(observers);
        for (var i = ids.length - 1; i >= 0; i--) {
            unobserve(ids[i]);
        }
    }

    function getDir() {
        return dir;
    }

    return {
        _initialized: true,
        _version: '2.3',
        observe: observe,
        unobserve: unobserve,
        destroy: unobserve,
        refresh: refresh,
        refreshAll: refreshAll,
        resetState: resetState,
        has: has,
        getActiveIds: getActiveIds,
        destroyAll: destroyAll,
        getScrollDirection: getDir
    };

})(typeof RB_VIEWPORT_OBSERVER !== 'undefined' ? RB_VIEWPORT_OBSERVER : undefined);
