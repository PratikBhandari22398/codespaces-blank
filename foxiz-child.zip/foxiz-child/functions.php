<?php
/* foxiz child theme */